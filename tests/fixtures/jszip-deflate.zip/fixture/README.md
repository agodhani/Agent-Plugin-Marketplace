# Fixture plugin
Used by the zip reader unit tests.
